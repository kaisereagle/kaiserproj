
-BUBBLESTAR-CHAN-
 
So this base a little info about it....

Do no report my base, first inform me and explain and I will fix the rule breaks or remove
the download. I will try to find a workaround.

Edit and distribute on finished models

Credit TDA, Yami and BubbleStar-Chan (I used the textures of Yami)

The base was R18 but I turned it into a decent base.

Enjoy the base and please link back or paste this in your description :iconBubbleStar-chan:

Inform me of any issues and I will try to fix them!

------------------------------
-FROM YAMI-
Distribution only in finished models
Must credit Tda & Yami Sweet